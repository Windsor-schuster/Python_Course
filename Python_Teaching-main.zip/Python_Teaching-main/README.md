# Python_Teaching
Some bits and pieces for teaching some Python
